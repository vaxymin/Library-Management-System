package com.company;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {

    public Connection get_connection() throws SQLException{
        String url ="jdbc:postgresql://localhost:5432/postgres";
        String user = "postgres";
        String password = "postgres";

        try {
            Connection connection = DriverManager.getConnection(url,user,password);
            return connection;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }

    }
}
